import React from "react";

const Contributors = () => {
  return <div>contributors</div>;
};

export default Contributors;
