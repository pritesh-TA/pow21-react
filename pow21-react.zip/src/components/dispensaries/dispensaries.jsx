import React from "react";

const Dispensaries = () => {
  return <div>dispensaries</div>;
};

export default Dispensaries;
